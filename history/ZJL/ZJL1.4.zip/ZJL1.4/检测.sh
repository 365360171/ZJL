cd "${0%/*}"
chmod -R 777 *
./*/ZJL