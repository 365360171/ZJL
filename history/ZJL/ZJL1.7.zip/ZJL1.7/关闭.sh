cd "${0%/*}"
chmod -R 777 * >/dev/null 2>&1
./*/ZJL OFF