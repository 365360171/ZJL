echo ""
if [[ `pgrep tiny` != "" ]]
then echo " tiny 已开启 ✅\n"
elif [[ `pgrep CProxy` != "" ]]
then echo " CProxy 已开启 ✅\n"
elif [[ `pgrep localproxy` != "" ]]
then echo " localproxy 已开启 ✅\n"
else echo " 什么都没开启 ❌\n";fi

if [[ `pgrep pdnsd` != "" ]]
then echo " pdnsd 已开启 ✅\n";fi

if [[ `pgrep redsocks2` != "" ]]
then echo " redsocks2 已开启 ✅\n";fi



echo "━━━ nat ━━━"

iptables -t nat -S

echo "\n\n━━━ mangle ━━━"

iptables -t mangle -S
