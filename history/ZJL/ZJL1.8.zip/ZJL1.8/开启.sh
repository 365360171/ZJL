cd "${0%/*}"
./*/busybox chmod -R 777 * >/dev/null 2>&1
./*/ZJL OFF ON