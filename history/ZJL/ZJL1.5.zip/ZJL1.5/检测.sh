cd "${0%/*}"
chmod -R 777 * 2>/dev/null
./*/ZJL 2>/dev/null