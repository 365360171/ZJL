cd "${0%/*}";. ./*.ini;MS=`$BU cat . ./*.conf`;rm ./*.bak;rm ./.*.bak;rm ./*/*.bak;chmod 777 *;chmod 777 .*;chmod 777 ./*/*;BU=./*/busybox;IPT=./*/iptables;JRDAPN=`dumpsys connectivity | $BU grep -v "<unknown"| $BU grep -v "(none)"| $BU grep extra | $BU awk '{print $9}' | $BU cut -d "," -f 1`;ZJL=`$IPT -nL -t nat | $BU grep ZJL`;JRDDL=`echo ${HQJRD#*HttpProxy:}| $BU cut -d "[" -f 2| $BU cut -d "]" -f 1`;JRDDK=`echo ${HQJRD#*$JRDDL}| $BU cut -d " " -f 2`;HQJRD=`dumpsys connectivity | $BU grep "HttpProxy:"`;NWIP=`$BU ip addr | $BU grep global | $BU grep -v inet6 | $BU grep -v "192.168" | $BU awk '{print $2}' | $BU cut -d "/" -f 1`
for Z in `$BU ifconfig`;do
for J in `$BU cat /data/misc/net/rt_tables`;do
if [[ $Z = "$J" ]]
then L="$J";fi;done;done
echo "\n——————————防跳信息——————————\n\n      ZJL 1.2  by:龍哥\n"
echo "——————————本机信息——————————\n"
if [[ $MS != "" ]]
then if [[ $HX != "" ]]
then if [[ `$BU pgrep $HX` != "" ]]
then echo "  免流核心 : $HX 已开启 ✔ \n"
else echo "  免流核心 : $HX 未开启 ✘ \n";fi
else echo "  免流核心 : 配置里未选择核心 ✘ \n";fi
else echo "  免流模式 : 未检测到模式 ✘ \n";fi
if [[ $ZJL != "" ]]
then echo "  ZJL防跳 : ZJL 已开启 ✔ \n"
else echo "  ZJL防跳 : ZJL 未开启 ✘ \n";fi
if [[ $JRDDL$JRDDK = "" ]]
then jrddl="代理留空";fi
if [[ $L != "wlan0" ]]
then JRD="\n\n   接入点 : $JRDAPN $jrddl$JRDDL $JRDDK"
if [[ $NWIP != "" ]]
then echo "   内网IP : $NWIP $JRD\n"
else echo "  网络类型 : 网络没有准备好 ✘ \n";fi
else echo "  网络类型  : Wifi奔放中  \n";fi
echo "——————————本机设置——————————\n"
if [[ $BJJ != "" ]]
then echo "  禁网UID  : $BJJ \n";fi
if [[ $BJF != "" ]]
then echo "  放行UID  : $BJF \n";fi
if [[ $BJJS != "" && $BJJS != "ON" ]]
then echo "  禁网HTTPS: $BJJS \n"
else if [[ $BJJS = "ON" ]]
then echo "  禁网HTTPS: 本机全禁网 ✘\n";fi;fi
if [[ $BJFS != "" && $BJFS != "ON" ]]
then echo "  放行HTTPS: $BJFS \n"
else if [[ $BJFS = "ON" ]]
then echo "  放行HTTPS: 本机全放行 ✔\n";fi;fi
if [[ $BJFU != "" && $BJFU != "ON" ]]
then echo "  放行UDP  : $BJFU \n"
else if [[ $BJFU = "ON" ]]
then echo "  放行UDP  : 本机全放行 ✔\n";fi;fi
if [[ $FXYX != "" ]]
then echo "  放行游戏  : 王者|球球|cf ✔\n";fi
echo "——————————共享设置——————————\n"
if [[ $GXWL != "ON" && $GXWL != "OFF" ]]
then echo "  共享网络  : 已代理 ✔\n"
else if [[ $GXWL = "OFF" ]]
then echo "  共享网络  : 已禁网 ✘\n"
else echo "  共享网络  : 已放行 ✔\n";fi;fi
if [[ $GXS != "ON" && $GXS != "OFF" ]]
then echo "  HTTPS   : 已代理 ✔\n"
else if [[ $GXS = "OFF" ]]
then echo "  HTTPS   : 已禁网 ✘\n"
else echo "  HTTPS   : 已放行 ✔\n";fi;fi
if [[ $GXFU = "ON" ]]
then echo "  放行UDP  : 已开启 ✔\n";fi
echo "——————————————————————————"