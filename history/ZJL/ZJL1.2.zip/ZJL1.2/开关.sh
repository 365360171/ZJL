cd "${0%/*}"
./.ZJL
sleep 0.5
./检测.sh