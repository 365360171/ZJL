echo ""
if [[ `pgrep tiny` != "" ]]
then echo " tiny 已开启 ✅\n"
elif [[ `pgrep CProxy` != "" ]]
then echo " CProxy 已开启 ✅\n"
elif [[ `pgrep localproxy` != "" ]]
then echo " localproxy 已开启 ✅\n"
else echo " 什么免流核心都没开 ❌\n";fi

if [[ `pgrep pdnsd` != "" ]]
then echo " pdnsd 已开启 ✅\n";fi

if [[ `pgrep redsocks2` != "" ]]
then echo " redsocks2 已开启 ✅\n";fi


echo "━━━ nat ━━━"
echo
for ZJL in OUTPUT PREROUTING
do
iptables -t nat -S ${ZJL}
echo
done

echo "\n\n━━━ mangle ━━━"
echo
for ZJL in OUTPUT FORWARD PREROUTING
do
iptables -t mangle -S ${ZJL}
echo
done

echo "\n\n━━━ ipv6 mangle ━━━"
echo
for ZJL in OUTPUT FORWARD
do
ip6tables -t mangle -S ${ZJL}
echo
done
