# 该脚本将在卸载期间执行，您可以编写自定义卸载规则
[ -d /data/ZJL2.0_magisk ] && rm -rf /data/ZJL2.0_magisk
[ -d /data/防跳/ZJL2.0_magisk ] && rm -rf /防跳/data/ZJL2.0_magisk
